rm -f src/*/*.class
