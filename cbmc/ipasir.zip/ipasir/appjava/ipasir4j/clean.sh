rm -fr cppsrc/picosat-961
rm -f cppsrc/*.o cppsrc/*.so
rm -fr ipasir4j
rm -f *.so *.jar
